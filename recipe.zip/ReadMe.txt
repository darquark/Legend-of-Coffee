Project Name: Legend of Coffee
Created by:Ece Yildirim

1)How to open Project?
Firstly, the user must open recipe file after that open coffee file and then open coffe.html file to reach to site. Then recipes can be viewed on the home page with the view recipe button at the bottom of each recipe. Likewise about and faq sections can be viewed with a navigation section on each page.




2)Description:This project was done by using HTML and CSS. The project name is Legend of Coffee, it contains a total of 6 coffee recipes. The project starts with the home page. There are 6 recipe cards on the main page, to view the details of the recipes, click on the view recipe button.When you click to view details of a recipe, there is a back button in the upper left corner of the page to return to the main page, using this button to return to the main page.Information about the site and the purpose of the site can be seen in the about tab in the navigation menu.Frequently asked questions and their answers can be seen in the FAQ tab in the navigation menu.

3)About Files
This project contains html,css,picture files.
Homepage File --> coffe.html
CSS File--> style.css
Subsections (Tab) Files --> about.html,faq.html,tarif1.html tarif2.html,tarif3.html,tarif4.html,tarif5.html,tarif6.html
Pictures located in the photos and photos 2 tab files.
Icon located to icons tab file.

4) Special information 

## Cosmic Latte - The Perfect Blend

The choice of background color, Cosmic Latte, reflects the perfect blend of coffee latte, just like the universe is an exquisite mix of various elements, coffee creations combine different flavors, aromas, and brewing techniques to delight your taste buds.

I took inspiration from the colors of the cosmos and the rich warmth of the coffee blend for choosing the background color.